/*
 * 27th March 1996. Added by Jan-Piet Mens for matching regular expressions
 * 		    in paths.
 * 
 */

/*
 * 	$Id: match.h,v 1.1 1997/02/23 15:56:12 eric Rel $
 */

#include "fnmatch.h"

void add_match();
int matches();

void i_add_match();
int i_matches();

void j_add_match();
int j_matches();

#ifdef APPLE_HYB
void hfs_add_match();
int hfs_matches();
#endif /* APPLE_HYB */
